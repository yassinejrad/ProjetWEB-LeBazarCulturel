<?php
use PHPMailer\PHPMailer\PHPMailer;

require_once 'phpmailer/Exception.php';
require_once 'phpmailer/PHPMailer.php';
require_once 'phpmailer/SMTP.php';
$conn = new mysqli("localhost","root","","bazarculturelle") ;
$ID=$_GET['ID'] ;
$sqlt = "select * from user where id='$ID'";
$resultz = $conn->query($sqlt) or die($conn->error);
$alert = '';
$mail = new PHPMailer(true);
while ($rowz= $resultz->fetch_assoc()) 
 {
  $add=$rowz['EMAIL'] ;
$type=$rowz['BLOQUER'] ;
 }

 if ($type==1) {
  $message =" It seems that you broke some rules so you compt is banned please contact the administrator for more details .  PS:THIS MESSAGE WAS WRITTEN BY A ROBOT SO DO NOT RESPOND PLEASE .
  ";
  }
  else {
    $message ="Congratulations your account is active again welcome again .PS:THIS MESSAGE WAS WRITTEN BY A ROBOT SO DO NOT RESPOND PLEASE .
    ";
  }
  
  $name = "LeBazarCulturel" ;
  $email = "aderssadhia@gmail.com" ;


  try{
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'aderssadhia@gmail.com'; // Gmail address which you want to use as SMTP server
    $mail->Password = 'dhia1881'; // Gmail address Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = '587';

    $mail->setFrom('aderssadhia@gmail.com'); // Gmail address which you used as SMTP server
    $mail->addAddress($add); // Email address where you want to receive emails (you can use any of your gmail address including the gmail address which you used as SMTP server)

    $mail->isHTML(true);
    $mail->Subject = 'Message Received (Contact Page)';
    $mail->Body = "<h3>Name : $name <br>Email: $email <br>Message : $message</h3>";

    $mail->send();
    
    echo"yeees" ; 
    $alert = '<div class="alert-success">
                 <span>Message Sent! Thank you for contacting us.</span>
                </div>';
                
                header('Location:afficheU2.php');

  } catch (Exception $e){
    $alert = '<div class="alert-error">
                <span>'.$e->getMessage().'</span>
              </div>';
  
            echo $e->getMessage() ;
            }

?>
