<?php  
	include_once "../../config.php";
	include_once 'commande.php';
	class commandeC {
		/////////////////////////////////////////////////////////////////////////////////
		/////////////////////// Afficher commande ////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////
		function  afficherCommande(){
			$sql="SELECT * FROM commande ";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
		}
		/////////////////////////////////////////////////////////////////////////////////
		/////////////////////// Supprimer commande //////////////////////////
		/////////////////////////////////////////////////////////////////////////////////
		function supprimerCommande($id){
			$sql="DELETE FROM commande WHERE ID= :ID ";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':ID',$id);
			try{
				$req->execute();
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		/////////////////////////////////////////////////////////////////////////////////
		/////////////////////// Confirmer commande //////////////////////////
		/////////////////////////////////////////////////////////////////////////////////
		function modifierCommande($commande,$id){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE commande SET 
						etat = :etat
					WHERE id = :id'
				);
				$query->execute([
					'etat' => $commande->getEtat(),
					'id' => $id
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

		/////////////////////////////////////////////////////////////////////////////////
		/////////////////////// rechercher une commande //////////////////////////
		/////////////////////////////////////////////////////////////////////////////////
		function chercherCommande($id) {
            $sql="SELECT * FROM commande where id='$id'";
            $db=Config::getConnexion();
            try{
            $liste = $db->query($sql);
            return $liste;
            } 
            catch (PDOException $e) {
                $e->getMessage();
            }
        }
		/////////////////////////////////////////////////////////////////////////////////
		/////////////////////// trier  commande //////////////////////////
		/////////////////////////////////////////////////////////////////////////////////
		function  trierCommande(){
			$sql="SELECT * FROM commande ORDER BY prix ASC ";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
		}
		/////////////////////////////////////////////////////////////////////////////////
		/////////////////////// chercher  commande //////////////////////////
		/////////////////////////////////////////////////////////////////////////////////
		public function chercher($str) {
			$sql="SELECT * FROM commande where id ='$str' OR  id_user='$str' "  ;
			$db=Config::getConnexion();
			try{
			$liste = $db->query($sql);
			return $liste;
			} 
			catch (PDOException $e) {
				$e->getMessage();
			}
		}
		public function chercherid($id) {
			$sql="SELECT * FROM commande where id=:id";
			$db=Config::getConnexion();
			try{
				$query=$db->prepare($sql);
			$query->execute(['id' =>$id]);
			$liste=$query->fetch();
			return $liste;
			} 
			catch (PDOException $e) {
				$e->getMessage();
			}
		}
	}
?>