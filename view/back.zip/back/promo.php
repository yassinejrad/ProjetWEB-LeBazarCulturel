<?PHP
	include "../../controller/promoC.php";
	$promotionC = new promotionC();
	$listepromotion = $promotionC->afficherpromotion();
  $listepromotion = $promotionC->tripromotion();
?>

<!DOCTYPE html>
<html lang="en">
<!doctype html>
<html class="no-js" lang=""> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

</head>
<body>
<?php include_once 'header_back.php'; ?>
<p class="mt-4 mb-4">
    </p>
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index_back.php">Acceuil</a>
      </li>
      <li class="breadcrumb-item active">Afficher promotion</li>
    </ol>
    </ol>

    <div class="col-lg-100">
    <div class="card">
     <div class="card-header">
    <strong class="card-title">Table de promotion</strong>
    </div>
    
    <div class="card-body">
     <table class="table">
    <thead class="badge-info">
     <tr>
      <th scope="col" >Id promotion</th>
      <th scope="col">Titre</th>
      <th scope="col">Date debut</th>
      <th scope="col">Date fin</th>
      <th scope="col">Pourcentage</th>
      <th scope="col">id produit</th>
      <th scope="col">Modifier</th>
      <th scope="col">Supprimer</th>
    </tr>
   </thead>
   <?PHP
	foreach($listepromotion as $promotion){
	?>
    <tbody>
    <tr>
    <th ><h5> <?php echo $promotion['idPromo'] ?></h5> </th>
    <td > <h5>  <?php echo $promotion['titre'] ?> </h5> </td>  
    <td > <h5> <?php echo $promotion['dateD'] ?>  </h5> </td> 
    <td > <h5> <?php echo $promotion['dateF'] ?>  </h5> </td>
    <td > <h5> <?php echo $promotion['pourcentage'] ?> % </h5> </td> 
    <td > <h5> <?php echo $promotion['idProduit'] ?></h5> </td> 
  <td> <a href="modifierpromo.php?id=<?PHP echo $promotion['idPromo']; ?>" id="idPromo" name="idPromo" ><button type="button" class="btn btn-outline-info  w-100 p-2 " class="btn badge-info"><i class="fa fa-pencil" aria-hidden="true"></i> </button></a> </td>
  <td> <a href="suppromo.php?id=<?PHP echo $promotion['idPromo']; ?>" id="idPromo" name="idPromo" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>  </a> </td>

      </tr>                 
      </tbody>
      <?php
    }
    ?>
     </table>
    </div>
    </div>
    </div>
    
                 

<!-- ajouter-->
        <a href="aadpromo.php" ><button type="button" class="btn btn-outline-dark  w-100 p-2" class="btn badge-info"><i class="fa fa-plus" aria-hidden="true"></i></button>  </a>
        <a href="../front/contact/index.php" ><button type="button" class="btn btn-outline-dark  w-100 p-2" class="btn badge-info"><i class="fa fa-envelope" aria-hidden="true"></i></button>  </a>
          
           

            
        <?php include_once 'footer_back.php'; ?>
        <!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
