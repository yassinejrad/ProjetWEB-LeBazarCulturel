<?PHP
	include "../../controller/promoC.php";
	$promotionC = new promotionC();
	$listepromotion = $promotionC->afficherpromotion();
  $listepromotion = $promotionC->tripromotion();
  $promo=new promotionC();

  $tp2= new promotionC();
  if(!isset($_POST['str'])){
    $listepromotion = $tp2->afficherpromotion();
}
else{
    $listepromotion = $tp2->chercher($_POST['str']);
} 

	foreach($listepromotion as $promotion){
	?>
    <tr>
    <th ><h5> <?php echo $promotion['idPromo'] ?></h5> </th>
    <td > <h5>  <?php echo $promotion['titre'] ?> </h5> </td>  
    <td > <h5> <?php echo $promotion['dateD'] ?>  </h5> </td> 
    <td > <h5> <?php echo $promotion['dateF'] ?>  </h5> </td>
    <td > <h5> <?php echo $promotion['pourcentage'] ?> % </h5> </td> 
    <td > <h5> <?php echo $promo->get_produit_name($promotion['idProduit']) ?></h5> </td> 
  <td> <a href="modifierpromo.php?id=<?PHP echo $promotion['idPromo']; ?>" id="idPromo" name="idPromo" ><button type="button" class="btn btn-outline-info  w-100 p-2 " class="btn badge-info"><i class="fa fa-pencil" aria-hidden="true"></i> </button></a> </td>
  <td> <a href="suppromo.php?id=<?PHP echo $promotion['idPromo']; ?>" id="idPromo" name="idPromo" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>  </a> </td>

      </tr>                 
      
      <?php
    }
    ?>
    
    


