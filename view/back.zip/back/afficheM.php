<?php 
include_once 'msgC.php';
include_once 'msg.php';
   // include_once  '../../controller/categorieC.php';
    //include_once '../../model/categorie.php';
    $msg= new msgC();
    $liste=$msg->affichermsg();
    //$cat1= new categorieC();
    //$liste2=$cat1->recupererCategorie();;
    //$tp2= new produitC();
  if(!isset($_POST['str'])){
    $liste=$msg->affichermsg();
  }
  else{
      $liste = $msg->chercher($_POST['str']);
  } 
   
 foreach($liste as $a) {
    ?>
   
    <tr> 

    <th>  <?php echo $a['id_m'] ?>  </th>
    <td>  <?php echo $a['id_s'] ?>  </td>
    <td>  <?php echo $a['id_r'] ?>  </td>
    <td>  <?php echo $a['date'] ?>  </td>
    <td>  <?php echo $a['message'] ?>  </td>
    
            <td>
             <a href="afficheM2.php?ID=<?php echo $a['id_m'] ?>" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>  </a>
        </td> 
       
            
           
        
        
    </tr>
  
    <?php
    }
    ?>

