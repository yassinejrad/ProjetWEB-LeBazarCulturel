<?php 
    include_once '../../controller/produitC.php';
    include_once '../../model/produit.php';
    include_once  '../../controller/categorieC.php';
    include_once '../../model/categorie.php';
    $produit1= new produitC();
    $liste=$produit1->afficherProduits();
    $cat1= new categorieC();
    $liste2=$cat1->recupererCategorie();;
    $tp2= new produitC();
  if(!isset($_POST['str'])){
      $liste = $tp2->afficherProduits();
  }
  else{
      $liste = $tp2->chercher($_POST['str']);
  } 
   
 foreach($liste as $a) {
    ?>
   
    <tr> 

    <th>  <?php echo $a['REFERENCE'] ?>  </th>
    <th>  <?php echo $a['NOM'] ?>  </th>
    <th>  <?php echo $a['QTE'] ?>  </th>
    <th>  <?php echo $a['DATE'] ?>  </th>
    <th>  <?php echo $a['PRIX'] ?> dt  </th>

    <th><img src= "<?php echo $a['IMAGE']?>" accept="image/png,image/jpeg" width="100" height="100"> </th>
    <th>  <?php echo $a['DESCP'] ?>  </th>
    
    <th>  <?php echo $a['CATEGORIE'] ?>  </th>
    <td>  <?php echo $a['STATUE'] ?>  </td>

        <th >            
         <a href="editP.php?REFERENCE=<?php echo $a['REFERENCE'] ?>"> <button type="button" class="btn btn-outline-info  w-100 p-2 " class="btn badge-info"><i class="fa fa-pencil" aria-hidden="true"></i> </button> </a>
        </th> <br>
            <th>
             <a href="afficheP2.php?REFERENCE=<?php echo $a['REFERENCE'] ?>" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-trash-o" aria-hidden="true"></i> </button> </a>
        </th> 
       
            
        
    </tr>
  
    <?php
    }
    ?>


