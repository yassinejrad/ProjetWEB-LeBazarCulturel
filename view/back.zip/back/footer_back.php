<div class="clearfix"></div>
<footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        CopyRight FreeDev 2021
                    </div>
                    
                </div>
            </div>
    </footer>

    </div>