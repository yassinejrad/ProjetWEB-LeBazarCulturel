<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

</head>
<body>
<?php include_once 'header_back.php'; ?>
<p class="mt-4 mb-4">
    </p>
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index_back.php">Acceuil</a>
      </li>
      <li class="breadcrumb-item active">Switch</li>
    </ol>


        <div class="content">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <i class="mr-2 fa fa-check-square-o"></i>
                                <strong class="card-title">3d Switch</strong>
                            </div>
                            <div class="card-body">
                                <label class="switch switch-3d switch-primary mr-3"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-3d switch-secondary mr-3"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-3d switch-success mr-3"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-3d switch-warning mr-3"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-3d switch-info mr-3"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-3d switch-danger mr-3"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                            </div>
                        </div>
                    </div><!--/.col-->

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Switch Default</strong>
                            </div>
                            <div class="card-body">
                                <label class="switch switch-default switch-primary mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-default switch-secondary mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-default switch-success mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-default switch-warning mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-default switch-info mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                                <label class="switch switch-default switch-danger mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                            </div>
                        </div>
                    </div><!--/.col-->

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Switch Default - Pills</strong>
                            </div>
                            <div class="card-body">
                                <label class="switch switch-default switch-pill switch-primary mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-pill switch-secondary mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-pill switch-success mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-pill switch-warning mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-pill switch-info mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-pill switch-danger mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                            </div>
                        </div>
                    </div><!--/.col-->

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Switch Outline</strong>
                            </div>
                            <div class="card-body">
                                <label class="switch switch-default switch-primary-outline mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-secondary-outline mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-success-outline mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-warning-outline mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-info-outline mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-danger-outline mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                            </div>
                        </div>
                    </div><!--/.col-->

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Switch Outline - Pills</strong>
                            </div>
                            <div class="card-body">
                                <label class="switch switch-default switch-primary-outline switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-secondary-outline switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-success-outline switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-warning-outline switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-info-outline switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-danger-outline switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                            </div>
                        </div>
                    </div><!--/.col-->

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Switch Outline Alternative</strong>
                            </div>
                            <div class="card-body">
                                <label class="switch switch-default switch-primary-outline-alt mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-secondary-outline-alt mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-success-outline-alt mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-warning-outline-alt mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-info-outline-alt mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-danger-outline-alt mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                            </div>
                        </div>
                    </div><!--/.col-->

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Switch Outline Alternative - Pills</strong>
                            </div>
                            <div class="card-body">
                                <label class="switch switch-default switch-primary-outline-alt switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-secondary-outline-alt switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-success-outline-alt switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-warning-outline-alt switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-info-outline-alt switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-default switch-danger-outline-alt switch-pill mr-2"><input type="checkbox" class="switch-input" checked="true"> <span class="switch-label"></span> <span class="switch-handle"></span></label>
                            </div>
                        </div>
                    </div><!--/.col-->

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Switch with Text</strong>
                            </div>
                            <div class="card-body">
                                <label class="switch switch-text switch-primary"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-secondary"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-success"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-warning"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-info"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-danger"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                            </div>
                        </div>
                    </div><!--/.col-->

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Switch with Text - Pills</strong>
                            </div>
                            <div class="card-body">

                                <label class="switch switch-text switch-primary switch-pill"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-secondary switch-pill"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-success switch-pill"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-warning switch-pill"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-info switch-pill"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                                <label class="switch switch-text switch-danger switch-pill"><input type="checkbox" class="switch-input" checked="true"> <span data-on="On" data-off="Off" class="switch-label"></span> <span class="switch-handle"></span></label>

                            </div>
                        </div>
                    </div><!--/.col-->

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" v-if="headerText">Sizes</strong>
                            </div>
                            <div class="card-body p-0">
                                <table class="table table-hover table-striped table-align-middle mb-0">
                                    <thead>
                                        <th>Size</th>
                                        <th>Example</th>
                                        <th>CSS Class</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                Large
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="lg" :checked="true"/>
                                            </td>
                                            <td>
                                                Add following code <code>size="lg"</code>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Default
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" :checked="true"/>
                                            </td>
                                            <td>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Small
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="sm" :checked="true"/>
                                            </td>
                                            <td>
                                                Add following code <code>size="sm"</code>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Extra small
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                Add following code <code>size="xs"</code>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div><!--/.col-->
                </div>

            </div><!-- .animated -->

        </div><!-- .content -->

        <?php include_once 'footer_back.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>
</html>
