<?php

$name = $_GET['name'];
$conn = new mysqli("localhost", "root", "", "bazarculturelle"); 


echo "$name" ; 

$sql = "delete from sponsor where name='$name'";
$result = $conn->query($sql);
$conn->close();

header("location: afficher_sponsor.php");





?>