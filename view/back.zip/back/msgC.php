<?PHP
    include_once 'config.php';
    include_once 'msg.php';
    
    

    class msgC {
        

   
          

        function  ajoutermsg($msg)
        {
            $sql="INSERT INTO msg (id_s,id_r,date,message) 
            VALUES (:id_s,:id_r,:date,:msg)" ;
            
            $db = config::getConnexion();
            try{
                $query = $db->prepare($sql) or die( $db->error); 
                
                $query->execute
                ([
                    'id_s' => $msg->getid_s(),
                    'id_r' => $msg->getid_r(),
                    'date' => $msg->getdate(),
                    'msg' => $msg->getmsg(),
              
                    
                ]); 
             
            }
            catch (Exception $e){
                echo 'Erreur: '.$e->getMessage();
            }           
        }
        
        function supprimermsg($reference){
            $sql="DELETE FROM msg    WHERE id_m=:ID";
            $db = config::getConnexion();
            $req=$db->prepare($sql);
            $req->bindValue(':ID',$reference);
            try{
                $req->execute();
                
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }

              
        function  affichermsg(){
            
            $sql="SELECT * FROM msg";
            $db = config::getConnexion();
            try{
                $liste = $db->query($sql);
                return $liste;
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }   
        }

        public function chercher($titre) {
            $sql="SELECT * FROM msg where id_m='$titre or id_r= $titre or id_s=$titre '";
            $db=Config::getConnexion();
            try{
            $liste = $db->query($sql);
            return $liste;
            } 
            catch (PDOException $e) {
                $e->getMessage();
            }
        }
     
        
      
        
    }

?>

