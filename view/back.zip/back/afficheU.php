<?php 
include_once 'userC.php';
include_once 'user.php';
   // include_once  '../../controller/categorieC.php';
    //include_once '../../model/categorie.php';
    $user1= new userC();
    $liste=$user1->afficherUser();
    //$cat1= new categorieC();
    //$liste2=$cat1->recupererCategorie();;
    //$tp2= new produitC();
  if(!isset($_POST['str'])){
    $liste=$user1->afficherUser();
  }
  else{
      $liste = $user1->chercher($_POST['str']);
  } 
   
 foreach($liste as $a) {
    ?>
   
    <tr> 

    <th>  <?php echo $a['ID'] ?>  </th>
    <td>  <?php echo $a['NOM'] ?>  </td>
    <td>  <?php echo $a['TEL'] ?>  </td>
    <td>  <?php echo $a['ADRESSE'] ?>  </td>
    <td>  <?php echo $a['EMAIL'] ?>  </td>
    <td>  <?php echo $a['PASSE'] ?>   </td>
    <td>  <?php echo $a['SEX'] ?>   </td>
    <td>  <?php echo $a['TYPE'] ?>   </td>
    <td>  <?php echo $a['DESCRIPTION'] ?>   </td>
    <td><img src= "<?php echo $a['IMG'] ?>" width="100" height="100"> </td>
    
        <td >            
         <a href="editU.php?ID=<?php echo $a['ID'] ?>"> <button type="button" class="btn btn-outline-info  w-100 p-2 " class="btn badge-info"><i class="fa fa-pencil" aria-hidden="true"></i> </button></a>
        </td> <br>
            <td>
             <a href="afficheU2.php?ID=<?php echo $a['ID'] ?>" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>  </a>
        </td> 
       

        <td>
             <a href="bloquer.php?ID=<?php echo $a['ID'] ?>" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><?php if  ($a['BLOQUER']==1) echo("DEBLOQUER") ; else  echo("BLOQUER") ; ?> <i class="fa fa-ban" aria-hidden="true"></i> </button> </a>
        </td> 
        
    </tr>
  
    <?php
    }
    ?>

