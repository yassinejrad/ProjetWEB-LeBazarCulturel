<?PHP
	include "../../controller/attenteaC.php";
	$attenteaC = new attenteaC();
	$listeattentea = $attenteaC->afficherattentea();
  $listeattentea = $attenteaC->triattentea();
?>

<!DOCTYPE html>
<html lang="en">
<!doctype html>
<html class="no-js" lang=""> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

</head>
<body>
<?php include_once 'header_back.php'; ?>
<section>
        <div class="container">
            <div class="title"><strong>attente article</strong></div>

            </br>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <button type="button" class="btn btn-primary">Search</button>
                    </div>
                    <input type="text" id="rech" class="form-control" placeholder="Look for a Product">
                </div>
            </div>
            </br>
            <div class="col-lg-100">
    <div class="card">
     <div class="card-header">
    <strong class="card-title">Table d'attente</strong>
    </div>
    
    <div class="card-body">
     <table class="table">
    <thead class="badge-info">
     <tr>
     <th scope="col" >Id attentea</th>
      <th scope="col">Titre</th>
      <th scope="col">Nom auteur</th>
      <th scope="col">Description</th>
      <th scope="col">Date</th>
      <th scope="col">image</th>
      <th scope="col">Accepter</th>
      <th scope="col">Reffuser</th>
    </tr>
   </thead>
   <tbody id="tableau">
  
   </table>
            
            </div>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
    load_data();

    function load_data(str) {
        $.ajax({
            url: "afficherA.php",
            method: "POST",
            data: {
                str: str
            },
            success: function(data) {
                $('#tableau').html(data);
            }
        });
    }

    $('#rech').keyup(function() {
        var recherche = $(this).val();
        if (recherche != '') {
            load_data(recherche);
        } else {
            load_data();
        }
    });
});
</script>

</div>
</section>
<a href="aadpromo.php" ><button type="button" class="btn btn-outline-dark  w-100 p-2" class="btn badge-info"><i class="fa fa-plus" aria-hidden="true"></i></button>  </a>
        <a href="../front/contact/index.php" ><button type="button" class="btn btn-outline-dark  w-100 p-2" class="btn badge-info"><i class="fa fa-envelope" aria-hidden="true"></i></button>  </a>
          

<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>