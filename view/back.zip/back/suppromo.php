<?PHP
	include_once '../../controller/promoC.php';
	
	$promotionC=new promotionC();
	
	if (isset($_GET['id']))
	{
		$promotionC->supprimerpromotion($_GET['id']);
		
		header('Location:promo2.php ' );
		
	}
?>