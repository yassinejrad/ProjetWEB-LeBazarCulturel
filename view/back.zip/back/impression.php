
<?PHP
	include "../../controller/articleC.php";
  include_once '../../model/article.php';

	$articleC = new articleC();
	$listearticle = $articleC->afficherarticles();
  $listearticle = $articleC->triarticle();
?>

<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
    <link href="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/jqvmap@1.5.1/dist/jqvmap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/weathericons@2.1.0/css/weather-icons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" rel="stylesheet" />
    </head>

    <body onload="window.print()">
    
    
    <div class="col-lg-100">
    <div class="card">
     <div class="card-header">
    <strong class="card-title">Table de article</strong>
    </div>
    
    <div class="card-body">
     <table class="table">
    <thead class="badge-info">
     <tr>
      <th scope="col" >Id article</th>
      <th scope="col">Titre</th>
      <th scope="col">Nom auteur</th>
      <th scope="col">Description</th>
      <th scope="col">Date</th>
      <th scope="col">image</th>

    </tr>
   </thead>
   <?PHP
	foreach($listearticle as $article){
	?>
    <tbody>
    <tr>
    <th ><h5> <?php echo $article['idA'] ?></h5> </th>
    <td > <h5>  <?php echo $article['titre'] ?> </h5> </td>  
    <td > <h5> <?php echo $article['nomAuteur'] ?>  </h5> </td> 
    <td > <h5> <?php echo $article['description'] ?>  </h5> </td> 
    <td > <h5> <?php echo $article['dateA'] ?>  </h5> </td>
    <td > <img class="card-img-top" src="../<?php echo $article["image"]; ?>"  alt="image"></td> 
    
      </tr>                 
      </tbody>
      <?php
    }
    ?>
     </table>
    </div>
    </div>
    </div>
    

   

<!-- Right Panel -->

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>


</body>
</html>