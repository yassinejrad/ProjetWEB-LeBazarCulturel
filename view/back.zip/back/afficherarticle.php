<?PHP
	include "../../controller/articleC.php";
  include_once '../../model/article.php';

	$articleC = new articleC();
	$listearticle = $articleC->afficherarticles();
  $listearticle = $articleC->triarticle();
  
  $tp2= new articleC();
  if(!isset($_POST['str'])){
    $listearticle = $tp2->afficherarticles();
}
else{
    $listearticle = $tp2->chercher2($_POST['str']);
}
	foreach($listearticle as $article){
?>
 
    <tr>
    <th ><h5> <?php echo $article['idA'] ?></h5> </th>
    <td > <h5>  <?php echo $article['titre'] ?> </h5> </td>  
    <td > <h5> <?php echo $article['nomAuteur'] ?>  </h5> </td> 
    <td > <h5> <?php echo $article['description'] ?>  </h5> </td> 
    <td > <h5> <?php echo $article['dateA'] ?>  </h5> </td>
    <td > <img class="card-img-top" src="../<?php echo $article["image"]; ?>"  alt="image"></td> 
    <td>  <a href="../../view/front/modifierarticle.php?id=<?PHP echo $article['idA']; ?>" ><button type="button" class="btn btn-outline-info  w-100 p-2 " class="btn badge-info"><i class="fa fa-pencil" aria-hidden="true"></i> </button></a></td>
  <td> <a href="../../view/front/supprimerarticle.php?id=<?PHP echo $article['idA']; ?>" id="idA" name="idA" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>  </a> </td>

      </tr>                 

      <?php
    }
    ?>

   