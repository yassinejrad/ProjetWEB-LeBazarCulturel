<?php
include "../../controller/produitC.php";
include_once '../../model/produit.php';
include_once  '../../controller/categorieC.php';
    include_once '../../model/categorie.php';
$error = "";

    // create article
   

    // create an instance of the controller
    $produitC = new produitC();
    
        if(isset($_POST['NOM']) ) { //S'il y a eu une recherche en crée le tableau avec le résultat
            $nom=$_POST['NOM'];
            $listepd=$produitC->chercher($nom);

    ?>
    <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <meta name="description" content="">
    <meta name="author" content="">

    <title>le bazar culturel</title>
    <link rel="shortcut icon" href="images/logo.png">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css" rel="stylesheet">
</head>
    <body>
        <!-- Navigation -->
    <?php include_once 'header_back.php'; ?>
  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <p class="mt-4 mb-4">
      
    <br>
    </p>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="blog.php">Blog</a>
      </li>
      <li class="breadcrumb-item active">Recherche Blog</li>
    </ol>

    <div class="row">
    <tr></tr>
    
    
      <!-- Blog Entries Column -->
      <div class="col-lg-100">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Show Table</strong>
                        </div>
                      <div class="card-body">
                      <div class="table-responsive">
                      <table class="table   table-bordered " width:"100%"; height:"100%" >
                      <thead class="badge-info">  
             <tr>
            <th scope="col">REFERENCE</th>
      <th scope="col">NOM</th>
      <th scope="col">PRIX</th>
      <th scope="col">DATE</th>
      <th scope="col">QTE</th>
      <th scope="col">IMAGE</th>
      <th scope="col">DESC</th>
      <th scope="col">CATEGORIE</th>
      <th scope="col">Modifier</th>
      <th scope="col">Supprimer</th>
    </tr>
    </thead>
    <?php
        foreach($listepd as $a) {
    ?>
    <tbody>
    <tr> 
    
        <td > <h5 style="color: rgb(7, 2, 36); ">  <?php echo $a['REFERENCE'] ?> </h5> </td>
        <td > <h5 style="color: rgb(7, 2, 36); ">  <?php echo $a['NOM'] ?> </h5> </td>  
        <td > <h5 style="color: rgb(7, 2, 36); "> <?php echo $a['PRIX'] ?>  </h5> </td> 
        <td > <h5 style="color: rgb(7, 2, 36); "> <?php echo $a['DATE'] ?>  </h5> </td>
        <td > <h5 style="color: rgb(7, 2, 36); "> <?php echo $a['QTE'] ?> dt </h5> </td> 
        <td > <img src= "<?php  echo $a['IMAGE']?>" width="100" height="100" /> </td> 
        <td > <h5 style="color: rgb(7, 2, 36); "> <?php echo $a['DESCP'] ?></h5> </td> 
        <td > <h5 style="color: rgb(7, 2, 36); "> <?php echo $a['CATEGORIE'] ?></h5> </td>  
        <td >            
         <a href="editP.php?REFERENCE=<?php echo $a['REFERENCE'] ?>"> <button type="button" class="btn badge-info">Modifier </button> </a>
        </td> <br>
            <td>
             <a href="afficheP.php?REFERENCE=<?php echo $a['REFERENCE'] ?>" ><button type="button" class="btn badge-info"> Supprimer </button> </a>
        </td> 
        
    </tr>
    </tbody>
    <?php
    }
    ?>
     <?php
    }
    ?>
    
    <?php include_once 'footer_back.php'; ?>
    </body>
</html>