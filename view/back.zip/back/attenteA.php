<?php 

    include_once '../../controller/attenteaC.php';
    include_once '../../controller/articleC.php';
    $attentea= new attenteaC();
    $liste=$attentea->afficherattentea();
 
        echo "echo ne requit pas de parenthèses.";
        if(isset($_GET['id'])) {
            // $article->ajouterarticles($user);
         
             //$attentea->supprimerattente($_GET['idA']);
            
         
    $cat=$_GET['id'];
    
    $conn=mysqli_connect("localhost","root","","bazarculturelle");
$sql="SELECT * FROM attentea where idA=".$cat." ";
$result=mysqli_query($conn,$sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);
$article=new articleC();
     while($arttentea=mysqli_fetch_assoc($result))
      {
$titre=$arttentea['titre'];
$nomAuteur=$arttentea['nomAuteur'];
$description=$arttentea['description'];
$dateA=$arttentea['dateA'];
$image=$arttentea['image'];

$user = new article(
    $titre,
    $nomAuteur,
    $description,
    $dateA,
    $image,

);

$article->ajouterarticle($user);
      }

      
      $attentea->supprimerattentea($_GET['id']);
   
    header('Location:afficherarticle2.php');
} 

   
    
?>