<?php 
include_once 'favorisC.php';
include_once 'favoris.php';
   // include_once  '../../controller/categorieC.php';
    //include_once '../../model/categorie.php';
    $favoris1= new favorisC();
    $liste=$favoris1->afficherfavoris();
    //$cat1= new categorieC();
    //$liste2=$cat1->recupererCategorie();;
    //$tp2= new produitC();
  if(!isset($_POST['str'])){
    $liste=$favoris1->afficherfavoris();
  }
  else{
      $liste = $favoris1->chercher($_POST['str']);
  } 
   
 foreach($liste as $a) {
    ?>
   
    <tr> 

    <th>  <?php echo $a['id'] ?>  </th>
    <td>  <?php echo $a['id_produit'] ?>  </td>
    <td>  <?php echo $a['id_user'] ?>  </td>
    <td>  <?php echo $a['date'] ?>  </td>

            <td>
             <a href="afficheF2.php?ID=<?php echo $a['id'] ?>" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>  </a>
        </td> 
       
            <td>
             <a href="imprimerF.php?ID=<?php echo $a['id'] ?>" ><button type="button" class="btn badge-info"> Imprimer </button> </a>
        </td> 
        
    </tr>
  
    <?php
    }
    ?>

