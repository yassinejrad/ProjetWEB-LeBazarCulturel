<?PHP
	include_once '../../controller/attenteaC.php';
	
	$attenteaC = new attenteaC();
	
	if (isset($_GET['id']))
	{
		$attenteaC->supprimerattentea($_GET['id']);
		
		header('Location:afficherA2.php');
		
	}
?>