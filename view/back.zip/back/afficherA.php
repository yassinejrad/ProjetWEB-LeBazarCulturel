<?PHP
	include "../../controller/attenteaC.php";
 
	$attenteaC = new attenteaC();
	$listeattentea = $attenteaC->afficherattentea();
  $listeattentea = $attenteaC->triattentea();
  $tp2= new attenteaC();
  if(!isset($_POST['str'])){
    $listeattentea = $tp2->afficherattentea();
}
else{
    $listeattentea = $tp2->chercher2($_POST['str']);
}
	foreach($listeattentea as $attentea){
	?>

    <tr>
    <th ><h5> <?php echo $attentea['idA'] ?></h5> </th>
    <td > <h5>  <?php echo $attentea['titre'] ?> </h5> </td>  
    <td > <h5> <?php echo $attentea['nomAuteur'] ?>  </h5> </td> 
    <td > <h5> <?php echo $attentea['description'] ?>  </h5> </td> 
    <td > <h5> <?php echo $attentea['dateA'] ?>  </h5> </td>
    <td > <img class="card-img-top" src="../<?php echo $attentea["image"]; ?>"  alt="image"></td> 
    <td >            
         <a href="attenteA.php?id=<?php echo $attentea['idA'] ?>"> <button type="button"  value="ACCEPT" id="ACCEPT" name="ACCEPT" class="btn btn-success  w-100 p-2" class="btn badge-info"><i class="fa fa-check" aria-hidden="true"></i></button> </a>
        </td> 
         <td >
    <a href="supAttenteA.php?id=<?php echo $attentea['idA'] ?>" ><button type="button"  class="btn btn-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-ban" aria-hidden="true"></i> </button> </a>
        </td> 
      </tr>                 
      
      <?php
    }
    ?>
    
    