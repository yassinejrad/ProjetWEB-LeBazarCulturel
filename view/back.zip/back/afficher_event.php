<?php

//include '../html/hey.php';
include '../../controller/eventc.php';


$conn = new mysqli("localhost", "root", "", "bazarculturelle");

$sql = "select * from event2  ";
$result = $conn->query($sql);

$conn->close();

?>

<!doctype html>

<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
    <style>




    </style>
</head>

<body>
    <?php include_once 'header_back.php'; ?> 
    <p class="mt-4 mb-4">
    </p>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index_back.php">Acceuil</a>
        </li>
        <li class="breadcrumb-item active">Afficher event</li>
    </ol>


    <div class="col-lg-100">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Table d'event</strong>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatableid" class="table   table-bordered  ">
                        <thead class="badge-info">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>location</th>
                                <th>start date</th>
                                <th>end date</th>
                                <th>description</th>
                                <th>artist1</th>
                                <th>artist2</th>
                                <th>artist3</th>
                                <th>sponsor1</th>
                                <th>sponsor2</th>
                                <th>sponsor3</th>
                                <th>image</th>
                                <th>price</th>
                                <th>Modifier</th>
                                <th>Supprimer</th>

                            </tr>
                        </thead>

                        <?php
                            while ($row = $result->fetch_assoc()) {
                                $evc = new Eventc;
                                //echo " ". $row['id'] . "";
                                $list = $evc->get_artists_names($row['id']);
                                $list_spons = $evc->get_sponsor_names($row['id']);

                                echo '
                                        <tr>
                                            <th>' . $row['id'] . '</th>
                                            <th>' . $row['name'] . '</th>
                                            <th>' . $row['location'] . '</th>
                                            <th>' . $row['start_date'] . '</th>
                                            <th>' . $row['end_date'] . '</th>
                                            <th>' . $row['description'] . '</th>
                                            <th>' . $list[0] . '</th>
                                            <th>' . $list[1] . '</th>
                                            <th>' . $list[2] . '</th>
                                            <th>' . $list_spons[0] . '</th>
                                            <th>' . $list_spons[1] . '</th>
                                            <th>' . $list_spons[2] . '</th>
                                            <th>' . $row['image'] . '</th>
                                            <th>' . $row['price'] . '</th>
                                            <th >            
                                            <a href="edit_event.php?name=' . $row['name'] . '"> <button type="button" class="btn btn-outline-info  w-100 p-2 " class="btn badge-info"><i class="fa fa-pencil" aria-hidden="true"></i> </button> </a>
                                           </th> <br>
                                               <th>
                                                <a href="delete_event.php?name=' . $row['name'] . '" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-trash-o" aria-hidden="true"></i> </button> </a>
                                           </th>
                                        </tr>
                                    ';
                            }
                        ?>

                    </table>
                </div>

            </div>
        </div>


        <a href="ajout_event.php" ><button type="button" class="btn btn-outline-dark  w-100 p-2" class="btn badge-info"><i class="fa fa-plus" aria-hidden="true"></i></button>  </a>
   

        <!-- Right Panel -->

        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
        <script src="assets/js/main.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>


        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>
        <script>
            /*$(document).ready(function() {
    $('#datatableid').DataTable();
} );*/
        </script>
        <?php include_once 'footer_back.php'; ?>
</body>

</html>