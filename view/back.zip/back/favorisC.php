<?PHP
    include_once "config.php";
    include_once 'favoris.php';
    
    

    class favorisC {
        

   
          

        function  ajouterfavoris($favoris)
        {
            $sql="INSERT INTO favoris (id_produit,date,id_user) 
            VALUES (:id_produit,:date,:id_user)" ;
            
            $db = config::getConnexion();
            try{
                $query = $db->prepare($sql) or die( $db->error); 
                
                $query->execute
                ([
                    'id_produit' => $favoris->getid_produit() ,
                    'date' => $favoris->getdate(),
                    'id_user' => $favoris->getid_user(),
              
                    
                ]); 
             
            }
            catch (Exception $e){
                echo 'Erreur: '.$e->getMessage();
            }           
        }
        
        function  afficherfavoris_s($ID){
            
            $sql="SELECT * FROM favoris f USER u where f.id_user==u.'$ID' ";
            $db = config::getConnexion();
            try{
                $liste = $db->query($sql);
                return $liste;
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }   
        }
        

        function supprimerfavoris($reference){
            $sql="DELETE FROM favoris    WHERE id=:ID";
            $db = config::getConnexion();
            $req=$db->prepare($sql);
            $req->bindValue(':ID',$reference);
            try{
                $req->execute();
                
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }

              
        function  afficherfavoris(){
            
            $sql="SELECT * FROM favoris";
            $db = config::getConnexion();
            try{
                $liste = $db->query($sql);
                return $liste;
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }   
        }

        public function chercher($titre) {
            $sql="SELECT * FROM favoris where id='$titre'";
            $db=Config::getConnexion();
            try{
            $liste = $db->query($sql);
            return $liste;
            } 
            catch (PDOException $e) {
                $e->getMessage();
            }
        }
     
      
        
    }

?>

