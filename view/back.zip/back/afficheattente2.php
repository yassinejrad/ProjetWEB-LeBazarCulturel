<?php 
    include_once '../../controller/categorieC.php';
    include_once '../../model/categorie.php';
    include_once '../../controller/produitC.php';
    include_once '../../model/produit.php';
    include_once '../../controller/attenteC.php';
    include_once '../../model/attente.php';
    $attente1= new attenteC();
    $liste=$attente1->afficherattente();
 
        echo "echo ne requit pas de parenthèses.";
        if(isset($_GET['REFERENCE'])) {
            // $produit->ajouterProduits($user);
         
             //$attente1->supprimerattente($_GET['REFERENCE']);
             
         
    $cat=$_GET['REFERENCE'];
    
    $conn=mysqli_connect("localhost","root","","bazarculturelle");
$sql="SELECT * FROM attente where REFERENCE=".$cat." ";
$result=mysqli_query($conn,$sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);
$produit=new ProduitC();
     while($art2=mysqli_fetch_assoc($result))
      {
$NOM=$art2['NOM'];
$PRIX=$art2['PRIX'];
$DATE=$art2['DATE'];
$QTE=$art2['QTE'];
$IMAGE=$art2['IMAGE'];
$DESCP=$art2['DESCP'];
$CATEGORIE=$art2['CATEGORIE'];
$USER=$art2['USER'];
$user = new produit(
    $NOM,
    $PRIX,
    $DATE,
    $QTE,
    $IMAGE,
    $DESCP,
    $CATEGORIE,
    $USER,
);

$produit->ajouterProduits($user);
      }

      
      $attente1->supprimerattente($_GET['REFERENCE']);
   
    header('Location:afficheAttente.php');
} 

   
    
?>