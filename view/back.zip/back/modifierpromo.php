<?php
	include '../../controller/promoC.php';
    include '../../Controller/produitC.php';

    $produitC = new produitC();
	$listeProduit= $produitC->afficherProduits();
    
    $error = "";
	$promotionC = new promotionC();
	if (
		isset($_POST["titre"]) && 
        isset($_POST["dateD"]) && 
        isset($_POST["dateF"]) && 
        isset($_POST["pourcentage"])&&
        isset($_POST["idProduit"])
	){
		if (
            !empty($_POST["titre"]) && 
            !empty($_POST["dateD"]) && 
            !empty($_POST["dateF"]) && 
            !empty($_POST["pourcentage"])&&
            !empty($_POST["idProduit"])
        ) {
            $promotion = new promotion(
                $_POST['titre'], 
                $_POST['dateD'],
                $_POST['dateF'],
                $_POST['pourcentage'],
                $_POST['idProduit'],
			);
			
            $promotionC->modifierpromotion($promotion, $_GET['id']);
            header('Location:promo.php');
        }
        else
            $error = "Missing information";
	}
?>

<html>
 <head>
 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le Bazar culturel</title>
    <meta name="pourcentage" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="img/logo.png">
    <link rel="shortcut icon" href="img/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
    <link href="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/jqvmap@1.5.1/dist/jqvmap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/weathericons@2.1.0/css/weather-icons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" rel="stylesheet" />
    </head>

    <body>
<?php include_once 'header_back.php'; ?>
<p class="mt-4 mb-4">
    </p>
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="promo.php">Acceuil</a>
      </li>
      <li class="breadcrumb-item active">Modifier promotion</li>
    </ol>

    <div class="col-md-8"> 
    <div id="error">     
            <?php echo $error; ?>
        </div>
 
<!--recupererpromotion-->  
		<?php
         if(isset($_GET['id']) ) {  
            $promotion=$promotionC->recupererpromotion($_GET['id']); 
		?>

		<form action="" method="POST">
        <table align="center">

    
                <tr>
                    
                    <td>
                        <label for="titre">titre:
                        </label>
                    </td>
                    <td><input type="text" name="titre" id="titre" maxlength="50" value="<?php echo $promotion['titre'];?>"></td>
                </tr>
                
                <tr>
                    <td>
                        <label for="dateD">dateD:
                        </label>
                    </td>
                    <td>
                        <input type="date_local" name="dateD" id="dateD" value="<?php echo $promotion['dateD'];?>" >
                        <script>
                                     $('#dateD').val(new Date().toJSON().slice(0,10));
                                    </script>
                    </td>
                </tr>

                <tr>
                    <td>
                        <label for="dateF">dateF:
                        </label>
                    </td>
                    <td>
                        <input type="date" name="dateF" id="dateF" value="<?php echo $promotion['dateF'];?>" >
                    </td>
                </tr>
                
                <tr>  
                    <td>
                        <label for="pourcentage">pourcentage:
                        </label>
                    </td>
                    <td><input type="number" name="pourcentage" id="pourcentage" maxlength="50" value="<?php echo $promotion['pourcentage'];?>"></td>
                </tr>

                <tr>  
                <td>
                        <label for="idProduit">idProduit:
                        </label>
                    </td>
                <td>
                    <select name="idProduit" id="idProduit" value="<?php echo $promotion['idProduit'];?>">
                     <option value="select" selected>Select</option>
                        
          <?php
          foreach($listeProduit as $produitC){
           ?>
           <option value ='<?PHP echo $produitC['REFERENCE']; ?>'> <?PHP echo $produitC['NOM']; ?></option>
           <?php
          }
          ?>
          </select>   
                     
                    </td> 
                </tr>
                
                
<tr>    
        <td>  <button type="button " href="promo.php" class="btn btn-default waves-effect " data-dismiss="modal ">Anuler</button> </td>
        <td> <button type="button " class="btn btn-primary " data-dismiss="modal ">Modifier</button> </td>
                           
            </tr>
            </table>             
        </form>

        <?php
        }
    ?>
	<?php include_once 'footer_back.php'; ?>
	</body>
</html>