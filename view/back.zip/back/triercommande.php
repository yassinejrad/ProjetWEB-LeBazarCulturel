<?php 
    include_once 'commandeC.php';
    include_once 'commande.php';
    $commande= new commandeC();
    $liste=$commande->afficherCommande();
    
    if(isset($_GET['id'])) {
        $produit1->supprimerProduits($_GET['id']);
        header('Location:affichecommande.php');
    } 
    
    
$error = "";
$pub  = null;
$comC = new commandeC();
$db= config::getConnexion();
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

</head>

<body>
    <?php include_once 'header_back.php'; ?>

    <p class="mt-4 mb-4">
    </p>
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index_back.php">Acceuil</a>
      </li>
      <li class="breadcrumb-item active">Afficher Commande</li>
    </ol>
        

                <div class="col-lg-1000">
            <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Table des Commandes</strong>
                        </div>
                        <form method="get" action="triercommande.php">
                            <p>
                                <label for="tri"><h4> Trier  :</h4> </label><br>
    
                                    <select name="tri" id="tri" >
                                       <option value="prix" selected>PRIX</option>
                                       <option value="etat">ETAT</option>
                                    </select>
                              </p>
                              <br>
                              
                                 <input type="submit" value="Trier" class ="btn btn-primary" /> 
                                
                             </form>
        
        <hr>
                      <div class="card-body">
                      <div class="col-lg-1000">
            <div class="table-responsive">
           
            <div class="col-lg-100">
                <table class="table   table-bordered" width:"100%" height:"100%">
                <div class="col-lg-1000">
                    <thead>
                        <tr>
                            <th >ID</th>
                            <th >id user</th>
                            <th >id panier</th>
                            <th >PRIX</th>
                            <th >ETAT</th>
                            
                        </tr>
    </thead>
    <?php
         $tri = isset($_GET['tri']) ? $_GET['tri'] : 'etat';
         try
 {
    $reponse = $db->query('SELECT * FROM commande ORDER BY '.$tri.'') or die(print_r($bdd->errorInfo()));  
          
                while($donnees = $reponse->fetch())
                {
   
    
    
                    echo  '<tr><td>'.$donnees['id'],
                    '</td><td>'. $donnees['id_user'],
                    '</td><td>'. $donnees['id_panier'],
                    '</td><td>'. $donnees['prix'],
                    '</td><td>'. $donnees['etat'],
                  
                    '</td></tr>';

        
        
  
}
             
$reponse->closeCursor();
}
catch(Exception $e)
{
die('Erreur : '.$e->getMessage());
}
?>
</table>
</div>                 
                     
                      </div>
                      </div>



    <?php include_once 'footer_back.php'; ?>

    <!-- Right Panel -->

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>