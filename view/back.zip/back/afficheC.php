<?php 
    include_once '../../controller/categorieC.php';
    include_once '../../model/categorie.php';

    $categorie1= new categorieC();
    $liste=$categorie1->afficherCategories();
    
    if(isset($_GET['CODE'])) {
        $categorie1->supprimerCategories($_GET['CODE']);
        header('Location:afficheC.php');
    }  
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    
        <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
        <link rel="stylesheet"
        href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
<style> 




</style>
</head>
<body>
<?php include_once 'header_back.php'; ?>
<p class="mt-4 mb-4">
    </p>
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index_back.php">Acceuil</a>
      </li>
      <li class="breadcrumb-item active">Afficher categorie</li>
    </ol>
        

                <div class="col-lg-30">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Table de Categorie</strong>
                        </div>
                      <div class="card-body">
                      <div class="table-responsive">
                      <table id="datatableid" class="table   table-bordered  " >
                      <thead class="badge-info">
             <tr>
            <th   scope="col">Code</th>
            <th  scope="col">NOM</th>
            <th   scope="col">Modifier</th>
            <th    scope="col">Supprimer</th>
     
    
    
    </tr>
    </thead>
    <?php
        foreach($liste as $a) {
    ?>
    <tbody>
    <tr> 
    
        <td > <h5 style="color: rgb(7, 2, 36); ">  <?php echo $a['CODE'] ?> </h5> </td>
        <td > <h5 style="color: rgb(7, 2, 36); ">  <?php echo $a['NOM'] ?> </h5> </td>  
        
        <td >            
         <a href="editC.php?CODE=<?php echo $a['CODE'] ?>"> <button style="width:auto;" type="button"   class="btn btn-outline-info  w-100 p-2" ><i class="fa fa-pencil" aria-hidden="true"></i></button> </a>
        </td><br>
            <td >
             <a href="afficheC.php?CODE=<?php echo $a['CODE'] ?>" ><button type="button" class="btn btn-outline-danger w-100 p-2 "><i class="fa fa-trash-o" aria-hidden="true"></i></button> </a>
        </td> 
        
    </tr>
    </tbody>
    <?php
    }
    ?>
</table>
</div>                 
                     
                      </div>
                      </div>
    
                    


<!-- Right Panel -->

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    
    
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>
<script>
/*$(document).ready(function() {
    $('#datatableid').DataTable();
} );*/
</script>
<?php include_once 'footer_back.php'; ?>
</body>
</html>
