<?php 

include_once '../../controller/produitC.php';
include_once '../../model/produit.php';
include_once '../../controller/categorieC.php';
include_once '../../model/categorie.php';
//require_once "../../config.php";
$hostname="localhost";
$username="root";
$password="";
$db = "bazarculturelle";
$dbh = new PDO("mysql:host=$hostname;dbname=$db", $username, $password);
?>
<html>
  <head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">
 

  
 <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">google.charts.load('current', {'packages':['geochart'],
       
        'mapsApiKey': 'AIzaSyCOauoie6dc0J9RZIqAaxL9mP8s3Xyocpw'
      });
      google.charts.setOnLoadCallback(drawRegionsMap);

      function drawRegionsMap() {
        var data = google.visualization.arrayToDataTable([
            ['COUNTRY', 'NUMBER OF USER '],
     
         <?php
      foreach($dbh->query('SELECT COUNTRY,COUNT(*)
      FROM user
      GROUP BY COUNTRY') as $row) {
        echo"['".$row['COUNTRY']."',".$row['COUNT(*)']."],";
      }
         ?>
           <?php
    
    ?>
        ]);

        var options = {

            
     
        colorAxis: {colors: ['green', 'blue','yellow']}
        };

        var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

        chart.draw(data, options);
      }
    </script>

  </head>
  <body>

                <!--  Traffic  -->
               
                                       
                                        <div id="regions_div" ></div>
                                        
                   
        <!-- /.content -->
        
    <!-- /#right-panel -->

    <!-- Scripts -->
   
    <!--Local Stuff-->
    
   
</body>

</html>