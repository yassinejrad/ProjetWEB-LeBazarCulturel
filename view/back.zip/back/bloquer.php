<?php 
$conn = new mysqli("localhost","root","","bazarculturelle") ;
$ID=$_GET['ID'] ;

   $sqlt = "select * from user where id='$ID'";
    $resultz = $conn->query($sqlt) or die($conn->error);

while ($rowz= $resultz->fetch_assoc()) 
 {
    if ($rowz["BLOQUER"]==0 )  {
        header('Location:sendemail.php?ID='.$ID.'');
        $sqlb = "   update user set BLOQUER=1  where id='$ID'";
        $resultb = $conn->query($sqlb) or die($conn->error);
        
    } 
    else {
        header('Location:sendemail.php?ID='.$ID.'');
        $sqld = " update user set BLOQUER=0  where id='$ID'";
        $resultd = $conn->query($sqld) or die($conn->error);
      

    }
     
 } 
   
   



?>