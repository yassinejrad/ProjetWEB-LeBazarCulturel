<?php 
    include_once 'commandeC.php';
    include_once 'commande.php';
  
    $tp2= new commandeC();
    if(!isset($_POST['str'])){
        $liste = $tp2->afficherCommande();
    }
    else{
        $liste = $tp2->chercher($_POST['str']);
    } 
   
 foreach($liste as $a) {
    ?>
   
    <tr> 

    <th>  <?php echo $a['id'] ?>  </th>
    <th>  <?php echo $a['id_user'] ?>  </th>
    <th>  <?php echo $a['id_panier'] ?>  </th>
    <th>  <?php echo $a['prix'] ?> dt </th>
    <th>  <?php echo $a['etat'] ?>   </th>


        <th >            
         <a href="editcommande.php?id=<?php echo $a['id'] ?>"> <button type="button" class="btn btn-outline-info  w-100 p-2 " class="btn badge-info"><i class="fa fa-pencil" aria-hidden="true"></i> </button> </a>
        </th> <br>
            <th>
             <a href="affichecommande2.php?id=<?php echo $a['id'] ?>" ><button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-trash-o" aria-hidden="true"></i> </button> </a>
        </th> 
       
            <th>
             <a href="imprimercommande.php?id=<?php echo $a['id'] ?>" ><button type="button" class="btn btn-outline-dark  w-100 p-2" class="btn badge-info"><i class="fa fa-print" aria-hidden="true"></i></button> </a>
        </th> 
        
    </tr>
  
    <?php
    }
    ?>

