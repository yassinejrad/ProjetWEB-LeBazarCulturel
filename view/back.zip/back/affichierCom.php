<?PHP
	include "../../controller/commentaireC.php";

	$commentaireC = new commentaireC();
	$listecommentaire = $commentaireC->affichercommentaires();
    $listecommentaire = $commentaireC->tricommentaire();
    $tp2= new commentaireC();
    if(!isset($_POST['str'])){
      $listecommentaire = $tp2->affichercommentaires();
  }
  else{
      $listecommentaire = $tp2->chercher($_POST['str']);
  }
	foreach($listecommentaire as $commentaire){
	?>
    <tbody>
    <tr>
    <th ><h5> <?php echo $commentaire['idCom'] ?></h5> </th> 
    <td > <h5> <?php echo $commentaire['message'] ?>  </h5> </td> 
    <td > <h5> <?php echo $commentaire['idA'] ?>  </h5> </td>
    <td > <h5>  <?php echo $commentaire['ID'] ?> </h5> </td>  
  <td> <a href="supCom.php?id=<?PHP echo $commentaire['idCom']; ?>" id="idCom" name="idCom" >  <button type="button" class="btn btn-outline-danger  w-100 p-2" class="btn badge-info"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> </button>
</a> </td>
  

      </tr>                 

      <?php
    }
    ?>

    

   