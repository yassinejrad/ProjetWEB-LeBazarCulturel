function ok() {
    alert("Votre produit a été ajouté avec succès!");
}


function surligne(myForm, erreur) {
    if (erreur)
        myForm.style.backgroundColor = "#fba";
    else
        myForm.style.backgroundColor = "";
}

function verifNB(myForm) {
    var NB = parseInt(myForm.value);
    if (isNaN(NB) || NB < 0) {
        surligne(myForm, true);
        return false;
    } else {
        surligne(myForm, false);
        return true;
    }
}

function verifReff(myForm) {
    if (myForm.value.length == 0) {
        surligne(myForm, true);
        return false;
    } else {
        surligne(myForm, false);
        return true;
    }

}

function verifform(f) {

    var NBOk = verifqteP(f.NB);
    var refOk = verifReff(f.ref);

    if (NBOk && refOk)
        return true;
    else {
        alert("Veuillez remplir correctement tous les champs");
        return false;
    }
}


function verifier() {
    var nom = document.getElementById("NOM").value



    if (nom.charAt(0) < "A" || nom.charAt(0) > "Z") {
        //alert("le nom doit etre en majuscule")
        document.querySelector("#erreur").innerHTML = "le nom doit etre en majuscule"
        return false
    }
}

function date() {
    $('#DATE').val(new Date().toJSON().slice(0, 10));
}