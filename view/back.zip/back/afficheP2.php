<?php 
    include_once '../../controller/produitC.php';
    include_once '../../model/produit.php';
    include_once  '../../controller/categorieC.php';
    include_once '../../model/categorie.php';
    
    $produit1= new produitC();
    $liste=$produit1->afficherProduits();
    
    if(isset($_GET['REFERENCE'])) {
        $produit1->supprimerProduits($_GET['REFERENCE']);
        header('Location:afficheP2.php');
    }  
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
<style type="text/css"> 
table, th, td {
  border: 100px solid black;
}

</style>
</head>

<body>
    <?php include_once 'header_back.php'; ?>

    <section>
        <div class="container">
            <div class="title"><strong>List of Product</strong></div>

            </br>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <button type="button" class="btn btn-primary">Search</button>
                    </div>
                    <input type="text" id="rech" class="form-control" placeholder="Look for a Product">
                </div>



            </div>
            </br>

            <div class="col-lg-50">
            <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Table de Produit</strong>
                        </div>
                      <div class="card-body">
                     
            <div class="table-responsive">
           
            
                <table class="table  table-hover table-bordered">
                
                    <thead class="badge-info">
                        <tr>
                            <th >REFERENCE</th>
                            <th >NOM</th>
                            <th >QTE</th>
                            <th >DATE</th>
                            <th >PRIX</th>
                            <th >IMAGE</th>
                            <th >DESC</th>
                            <th  >CATEGORIE</th>
                            <th>STATUE</th>
                            <th  >Modifier</th>
                            <th >Supprimer</th>
                        
                        </tr>
                    </thead>


                    
                    

                    <tbody id="tableau">
   </tbody>

                </table>
            
            </div>
           
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

            <script type="text/javascript">
            $(document).ready(function() {
                load_data();

                function load_data(str) {
                    $.ajax({
                        url: "afficheP.php",
                        method: "POST",
                        data: {
                            str: str
                        },
                        success: function(data) {
                            $('#tableau').html(data);
                        }
                    });
                }

                $('#rech').keyup(function() {
                    var recherche = $(this).val();
                    if (recherche != '') {
                        load_data(recherche);
                    } else {
                        load_data();
                    }
                });
            });
            </script>
            
        </div>
    </section>

    <a href="AjoutP.php" ><button type="button" class="btn btn-outline-dark  w-100 p-2" class="btn badge-info"><i class="fa fa-plus" aria-hidden="true"></i></button>  </a>
   
   <a href="imprimer.php" ><button type="button" class="btn btn-outline-dark  w-100 p-2" class="btn badge-info"><i class="fa fa-print" aria-hidden="true"></i></button> </a>
   <?php include_once 'footer_back.php'; ?>

    <!-- Right Panel -->

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>