<?php
include_once  '../../controller/produitC.php';
include_once '../../model/produit.php';
include_once  '../../controller/categorieC.php';
include_once '../../model/categorie.php';
$error = "";
$inf2= new categorieC();
  $liste=$inf2->recupererCategorie();
  $inf4= new categorieC();
  $liste1=$inf4->recupereruser();
  $inf3= new categorieC();
  $liste3=$inf2->afficherCategories();
// create user
$user = null;

// create an instance of the controller
$userC = new produitC();

if (
    isset($_POST["NOM"]) && 
    isset($_POST["PRIX"]) &&
    isset($_POST["DATE"]) && 
    isset($_POST["QTE"]) && 
    isset($_POST["IMAGE"])&& 
    isset($_POST["DESC"])&&
    isset($_POST["CATEGORIE"])&&
    isset($_POST["USER"])&&
    isset($_POST["STATUE"])
) {
    if (
        !empty($_POST["NOM"]) && 
        !empty($_POST["PRIX"]) && 
        !empty($_POST["DATE"]) && 
        !empty($_POST["QTE"]) && 
        !empty($_POST["IMAGE"]) && 
        !empty($_POST["DESC"]) &&
        !empty($_POST["CATEGORIE"])&&
        !empty($_POST["CATEGORIE"]) &&
        !empty($_POST["STATUE"])
        
    ) {
        $user = new produit(
            $_POST['NOM'],
            $_POST['PRIX'], 
            $_POST['DATE'],
            $_POST['QTE'],
            $_POST['IMAGE'],
            $_POST['DESC'],
            $_POST['CATEGORIE'],
            $_POST['USER'],
            $_POST['STATUE']
        );
        $userC->ajouterProduits($user);
        header('Location:afficheP2.php');
    }
    else
        $error = "Missing information";
}
    
?>


<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le Bazar culturel</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="img/logo.png">
    <link rel="shortcut icon" href="img/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
    <link href="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/jqvmap@1.5.1/dist/jqvmap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/weathericons@2.1.0/css/weather-icons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <style>
    .form-control {
        height: calc(2.4rem + 2px);
        border: 1px solid #444951;
        background: transparent;
        border-radius: 0;
        color: #979a9f;
        padding: 0.45rem 0.75rem;
    }

    input.form-control:valid {
        border: 3px solid #0a0;
    }

    input.form-control:invalid {
        border: 3px solid #a00;
    }

    input.form-control:valid+span:before {
        content: "\f00c";
        font-family: "FontAwesome";
        color: #0a0;
        font-size: 1.5em;
    }

    input.form-control:invalid+span:before {
        content: "\f00d";
        font-family: "FontAwesome";
        color: #a00;
        font-size: 1.5em;
    }

    #weatherWidget .currentDesc {
        color: #ffffff !important;
    }


    #flotPie1 {
        height: 150px;
    }

    #flotPie1 td {
        padding: 3px;
    }

    #flotPie1 table {
        top: 20px !important;
        right: -10px !important;
    }

    .chart-container {
        display: table;
        min-width: 270px;
        text-align: left;
        padding-top: 10px;
        padding-bottom: 10px;
    }

    #flotLine5 {
        height: 105px;
    }

    #flotBarChart {
        height: 150px;
    }

    #cellPaiChart {
        height: 160px;
    }
    </style>

    <script LANGUAGE="javascript">
    function ok() {
        alert("Votre produit a été ajouté avec succès!");
    }


    function surligne(myForm, erreur) {
        if (erreur)
            myForm.style.backgroundColor = "#fba";
        else
            myForm.style.backgroundColor = "";
    }

    function verifNB(myForm) {
        var NB = parseInt(myForm.value);
        if (isNaN(NB) || NB < 0) {
            surligne(myForm, true);
            return false;
        } else {
            surligne(myForm, false);
            return true;
        }
    }

    function verifReff(myForm) {
        if (myForm.value.length == 0) {
            surligne(myForm, true);
            return false;
        } else {
            surligne(myForm, false);
            return true;
        }

    }

    function verifform(f) {

        var NBOk = verifqteP(f.NB);
        var refOk = verifReff(f.ref);

        if (NBOk && refOk)
            return true;
        else {
            alert("Veuillez remplir correctement tous les champs");
            return false;
        }
    }


    function verifier() {
        var nom = document.getElementById("NOM").value



        if (nom.charAt(0) < "A" || nom.charAt(0) > "Z") {
            //alert("le nom doit etre en majuscule")
            document.querySelector("#erreur").innerHTML = "le nom doit etre en majuscule"
            return false
        }
    }

    function date() {
        $('#DATE').val(new Date().toJSON().slice(0, 10));
    }
    </script>
</head>


<body>
    <?php include_once 'header_back.php'; ?>
    <p class="mt-4 mb-4">
    </p>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index_back.php">Acceuil</a>
        </li>
        <li class="breadcrumb-item active">Ajouter produit</li>
    </ol>

    <!--/Ajout Product-->
    <form action="AjoutP.php" method="POST">
        <section class="no-padding-top">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="block margin-bottom-sm">
                            <div class="title"><strong>Product Table</strong></div>
                            <div class="table-responsive">
                                <div class="card-header">
                                    <i class="fas fa-table"></i> Ajouter un nouveau produit
                                </div>

                                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                    <form id="myForm" method="POST" onsubmit="return verifform(this)">

                                        <label style="font-weight: bold"> Nom du produit </label>
                                        <input type="text" class="form-control" id="NOM" name="NOM"
                                            placeholder="Nom du produit" value=" " onblur="verifier()"
                                            style="width:500px" pattern="[0-9a-zA-Z-\.]{3,12}" required> </br>
                                        <label style="font-weight: bold"> Description du produit </label>
                                        <textarea class="form-control" name="DESC" placeholder="Description  du produit"
                                            value=" " //onblur="verifReff(this) " style="width:500px" cols="30"
                                            rows="10" pattern="[0-9a-zA-Z-\.]{3,100}" required> </textarea> </br>
                                        <label style="font-weight: bold"> Prix dt </label>
                                        <input type="number" class="form-control" onblur="verifNB(this)"
                                            class="form-control " name="PRIX" value=" " min="0" max=""
                                            placeholder="Prix en Dt " style="width:200px " required></br>
                                        <label style="font-weight: bold">Date D'Ajout</label> </br>
                                        <input type="date-local" class="form-control" id="DATE" name="DATE" value=""
                                            required>
                                        </br>
                                        <label style="font-weight: bold">FreeQuantity</label> </br>
                                        <input type="number" class="form-control" id="quantite" name="QTE" min="0"
                                            max="" required>
                                        </br>
                                        <label style="font-weight: bold">CATEGORIE</label> </br>
                                        <select name="CATEGORIE" id="CATEGORIE" class="form-control mb-3 mb-3"
                                            onblur="verifReff(this)" required>
                                            <option> Select </option>
                                            <?php
                              foreach($liste as $t) {
                            ?>
                                            <option value = "<?php echo $t['CODE'] ?>"> <?php echo $t['NOM'] ?> </option>
                                            <?php
                              }
                            ?>
                                        </select>
                                        </br>
                                        <label style="font-weight: bold">USER</label> </br>
                                        <select name="USER" id="USER" class="form-control mb-3 mb-3"
                                            onblur="verifReff(this)" required>
                                            <option> Select </option>
                                            <?php
                              foreach($liste1 as $t) {
                            ?>
                                            <option> <?php echo $t['ID'] ?> </option>
                                            <?php
                              }
                            ?>
                                        </select>
                                        </br> 
                              
                              <label for="STATUE" style="font-weight: bold">Statue</label> </br>
                              <select name="STATUE" id="STATUE" class="form-control mb-3 mb-3" required >
                   <!--  <option value="select" selected>Select</option> -->
           <option value ="1"> nouveauté   </option>
  <option value ="2"> EN PROMO </option>
  </select>
                                        </br> <label style="font-weight: bold">Ajouter une photo</label></br>
                                        <input type="file" name="IMAGE" accept="image/png,image/jpeg" required>
                                        </br>
                                        </br>

                                        <input type="button"
                                            onclick="document.getElementById('id').style.display='block'" value="Save"
                                            name="Submit" class="btn btn-primary">
                                        <input type="reset" value="Cancel" name="reset" class="btn btn-secondary">
                                       <!-- <input type="submit" value="submit" name="submit" class="btn btn-primary"
                                            onclick="verifier()">-->
            

                                        <div id="id" class="modal">
                                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                <form method="POST" action="afficheP2.php">
                                                    <strong>Great !</strong> You just added a Product
                                                    <button type="button" class="close" data-dismiss="alert"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                    <div class="clearfix ">
                                                        <input type="submit"
                                                            onclick="document.getElementById('id').style.display='none'"
                                                            class="btn-secondary" value="Okay">
                                                    </div>
                                                </form>
                                            </div>
                                        </div>

                                        <script>
                                        var modal = document.getElementById('id')
                                        window.onclick = function(event) {
                                            if (event.target == modal) {
                                                modal.style.display = "none";
                                            }
                                        }
                                        </script>


                                        <script>
                                        $('#DATE').val(new Date().toJSON().slice(0, 10));
                                        </script>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </form>

    
    <p class="mt-4 mb-4">
    </p>
    <div class="col-lg-5">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Table de Categorie</strong>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table   table-bordered " width:"100%"; height:"100%">
                        <thead class="badge-info">
                            <tr>
                                <th scope="col">Code</th>
                                <th scope="col">NOM</th>
                            </tr>
                        </thead>
                        <?php
        foreach($liste3 as $a) {
    ?>
                        <tbody>
                            <tr>

                                <td>
                                    <h5 style="color: rgb(7, 2, 36); "> <?php echo $a['CODE'] ?> </h5>
                                </td>
                                <td>
                                    <h5 style="color: rgb(7, 2, 36); "> <?php echo $a['NOM'] ?> </h5>
                                </td>



                            </tr>
                        </tbody>
                        <?php
    }
    ?>
                    </table>
                </div>

            </div>
        </div>


        <!--/Ajout Product-->

                <!-- /.col-lg-8 -->

               
       
                                       
                            <!-- /.todo-list -->
                   

          
                                                      
        <!-- /#event-modal -->
        <!-- Modal - Calendar - Add Category -->
      
        <!-- /#add-category -->
    </div>
    <!-- .animated -->
    </div>
    <!-- /.content -->
    <?php include_once 'footer_back.php'; ?>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js "></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js "></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js "></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js "></script>
    <script src="assets/js/main.js "></script>

    <!--  Chart js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js "></script>

    <!--Chartist Chart-->
    <script src="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.js "></script>
    <script src="https://cdn.jsdelivr.net/npm/chartist-plugin-legend@0.6.2/chartist-plugin-legend.min.js "></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery.flot@0.8.3/jquery.flot.min.js "></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-pie@1.0.0/src/jquery.flot.pie.min.js "></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-spline@0.0.1/js/jquery.flot.spline.min.js "></script>

    <script src="https://cdn.jsdelivr.net/npm/simpleweather@3.1.0/jquery.simpleWeather.min.js "></script>
    <script src="assets/js/init/weather-init.js "></script>

    <script src="https://cdn.jsdelivr.net/npm/moment@2.22.2/moment.min.js "></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.js "></script>
    <script src="assets/js/init/fullcalendar-init.js "></script>
    <script src="script.js"></script>
    <!--Local Stuff-->
    <script>
    jQuery(document).ready(function($) {
        "use strict ";

        // Pie chart flotPie1
        var piedata = [{
            label: "Desktop visits ",
            data: [
                [1, 32]
            ],
            color: '#5c6bc0'
        }, {
            label: "Tab visits ",
            data: [
                [1, 33]
            ],
            color: '#ef5350'
        }, {
            label: "Mobile visits ",
            data: [
                [1, 35]
            ],
            color: '#66bb6a'
        }];

        $.plot('#flotPie1', piedata, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    innerRadius: 0.65,
                    label: {
                        show: true,
                        radius: 2 / 3,
                        threshold: 1
                    },
                    stroke: {
                        width: 0
                    }
                }
            },
            grid: {
                hoverable: true,
                clickable: true
            }
        });
        // Pie chart flotPie1  End
        // cellPaiChart
        var cellPaiChart = [{
            label: "Direct Sell ",
            data: [
                [1, 65]
            ],
            color: '#5b83de'
        }, {
            label: "Channel Sell ",
            data: [
                [1, 35]
            ],
            color: '#00bfa5'
        }];
        $.plot('#cellPaiChart', cellPaiChart, {
            series: {
                pie: {
                    show: true,
                    stroke: {
                        width: 0
                    }
                }
            },
            legend: {
                show: false
            },
            grid: {
                hoverable: true,
                clickable: true
            }

        });
        // cellPaiChart End
        // Line Chart  #flotLine5
        var newCust = [
            [0, 3],
            [1, 5],
            [2, 4],
            [3, 7],
            [4, 9],
            [5, 3],
            [6, 6],
            [7, 4],
            [8, 10]
        ];

        var plot = $.plot($('#flotLine5'), [{
            data: newCust,
            label: 'New Data Flow',
            color: '#fff'
        }], {
            series: {
                lines: {
                    show: true,
                    lineColor: '#fff',
                    lineWidth: 2
                },
                points: {
                    show: true,
                    fill: true,
                    fillColor: "#ffffff ",
                    symbol: "circle ",
                    radius: 3
                },
                shadowSize: 0
            },
            points: {
                show: true,
            },
            legend: {
                show: false
            },
            grid: {
                show: false
            }
        });
        // Line Chart  #flotLine5 End
        // Traffic Chart using chartist
        if ($('#traffic-chart').length) {
            var chart = new Chartist.Line('#traffic-chart', {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                series: [
                    [0, 18000, 35000, 25000, 22000, 0],
                    [0, 33000, 15000, 20000, 15000, 300],
                    [0, 15000, 28000, 15000, 30000, 5000]
                ]
            }, {
                low: 0,
                showArea: true,
                showLine: false,
                showPoint: false,
                fullWidth: true,
                axisX: {
                    showGrid: true
                }
            });

            chart.on('draw', function(data) {
                if (data.type === 'line' || data.type === 'area') {
                    data.element.animate({
                        d: {
                            begin: 2000 * data.index,
                            dur: 2000,
                            from: data.path.clone().scale(1, 0).translate(0, data.chartRect
                                .height()).stringify(),
                            to: data.path.clone().stringify(),
                            easing: Chartist.Svg.Easing.easeOutQuint
                        }
                    });
                }
            });
        }
        // Traffic Chart using chartist End
        //Traffic chart chart-js
        if ($('#TrafficChart').length) {
            var ctx = document.getElementById("TrafficChart ");
            ctx.height = 150;
            var myChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ["Jan ", "Feb ", "Mar ", "Apr ", "May ", "Jun ", "Jul "],
                    datasets: [{
                        label: "Visit ",
                        borderColor: "rgba(4, 73, 203,.09) ",
                        borderWidth: "1 ",
                        backgroundColor: "rgba(4, 73, 203,.5) ",
                        data: [0, 2900, 5000, 3300, 6000, 3250, 0]
                    }, {
                        label: "Bounce ",
                        borderColor: "rgba(245, 23, 66, 0.9) ",
                        borderWidth: "1 ",
                        backgroundColor: "rgba(245, 23, 66,.5) ",
                        pointHighlightStroke: "rgba(245, 23, 66,.5) ",
                        data: [0, 4200, 4500, 1600, 4200, 1500, 4000]
                    }, {
                        label: "Targeted ",
                        borderColor: "rgba(40, 169, 46, 0.9) ",
                        borderWidth: "1 ",
                        backgroundColor: "rgba(40, 169, 46, .5) ",
                        pointHighlightStroke: "rgba(40, 169, 46,.5) ",
                        data: [1000, 5200, 3600, 2600, 4200, 5300, 0]
                    }]
                },
                options: {
                    responsive: true,
                    tooltips: {
                        mode: 'index',
                        intersect: false
                    },
                    hover: {
                        mode: 'nearest',
                        intersect: true
                    }

                }
            });
        }
        //Traffic chart chart-js  End
        // Bar Chart #flotBarChart
        $.plot("#flotBarChart ", [{
            data: [
                [0, 18],
                [2, 8],
                [4, 5],
                [6, 13],
                [8, 5],
                [10, 7],
                [12, 4],
                [14, 6],
                [16, 15],
                [18, 9],
                [20, 17],
                [22, 7],
                [24, 4],
                [26, 9],
                [28, 11]
            ],
            bars: {
                show: true,
                lineWidth: 0,
                fillColor: '#ffffff8a'
            }
        }], {
            grid: {
                show: false
            }
        });
        // Bar Chart #flotBarChart End
    });
    </script>
</body>

</html>