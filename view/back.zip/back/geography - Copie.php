<?php 

include_once '../../controller/produitC.php';
include_once '../../model/produit.php';
include_once '../../controller/categorieC.php';
include_once '../../model/categorie.php';
//require_once "../../config.php";
$hostname="localhost";
$username="root";
$password="";
$db = "bazarculturelle";
$dbh = new PDO("mysql:host=$hostname;dbname=$db", $username, $password);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    window.__be = window.__be || {};
    window.__be.id = "60a10a5de2d8e8000768122e";
    (function() {
        var be = document.createElement('script'); be.type = 'text/javascript'; be.async = true;
        be.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.chatbot.com/widget/plugin.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(be, s);
    })();
</script>
<script type="text/javascript">google.charts.load('current', {'packages':['geochart'],
       
        'mapsApiKey': 'AIzaSyCOauoie6dc0J9RZIqAaxL9mP8s3Xyocpw'
      });
      google.charts.setOnLoadCallback(drawRegionsMap);

      function drawRegionsMap() {
        var data = google.visualization.arrayToDataTable([
            ['COUNTRY', 'NUMBER OF USER '],
     
         <?php
      foreach($dbh->query('SELECT COUNTRY,COUNT(*)
      FROM user
      GROUP BY COUNTRY') as $row) {
        echo"['".$row['COUNTRY']."',".$row['COUNT(*)']."],";
      }
         ?>
           <?php
    
    ?>
        ]);

        var options = {

            
     
        colorAxis: {colors: ['green', 'blue','yellow']}
        };

        var chart = new google.visualization.GeoChart(document.getElementById('aloe'));

        chart.draw(data, options);
      }
    </script>
 <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    window.__be = window.__be || {};
    window.__be.id = "60a10a5de2d8e8000768122e";
    (function() {
        var be = document.createElement('script'); be.type = 'text/javascript'; be.async = true;
        be.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.chatbot.com/widget/plugin.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(be, s);
    })();
</script>
<script type="text/javascript">google.charts.load('current', {'packages':['geochart'],
       
        'mapsApiKey': 'AIzaSyCOauoie6dc0J9RZIqAaxL9mP8s3Xyocpw'
      });
      google.charts.setOnLoadCallback(drawRegionsMap);

      function drawRegionsMap() {
        var data = google.visualization.arrayToDataTable([
            ['COUNTRY', 'NUMBER OF USER '],
     
         <?php
      foreach($dbh->query('SELECT COUNTRY,COUNT(*)
      FROM user
      GROUP BY COUNTRY') as $row) {
        echo"['".$row['COUNTRY']."',".$row['COUNT(*)']."],";
      }
         ?>
           <?php
    
    ?>
        ]);

        var options = {

            
     
        colorAxis: {colors: ['green', 'blue','yellow']}
        };

        var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

        chart.draw(data, options);
      }
    </script>

  </head>
  <body>
    <div id="regions_div" style="width: 900px; height: 500px;"></div>
  </body>
</html>