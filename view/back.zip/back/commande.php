<?PHP
class Commande
{
    private ?int $id_panier = null;
    private ?int $id_user = null ;
    private ?int $prix = null ;
    private ?string $etat = null ;

    function __construct(int $id_panier, int $id_user, int $prix, string $etat)
    {
        $this->id_panier = $id_panier;
        $this->id_user = $id_user;
        $this->etat = $etat;
        $this->prix = $prix;
    }
    function getIdpanier(): int
    {
        return $this->id_panier;
    }
    function getIduser(): int
    {
        return $this->id_user;
    }
    function getId(): int
    {
        return $this->id;
    }
    function getPrix(): int
    {
        return $this->prix;
    }
    function getEtat(): string
    {
        return $this->etat;
    }
    function setIduser(string $id_user): void
    {
        $this->id_user = $id_user;
    }
    function setIdproduit(string $id_panier): void
    {
        $this->id_panier = $id_panier;
    }
    
    function setEtat(string $etat): void
    {
        $this->etat = $etat;
    }
    function setPrix(string $prix): void
    {
        $this->prix = $prix;
    }
    
}
?>