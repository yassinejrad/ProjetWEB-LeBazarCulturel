<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le bazar culturel</title>
    <meta name="description" content="Le bazar culturel">
    <link rel="shortcut icon" href="images/logo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

</head>
<body>
<?php include_once 'header_back.php'; ?>
<p class="mt-4 mb-4">
    </p>
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index_back.php">Acceuil</a>
      </li>
      <li class="breadcrumb-item active">Grids</li>
    </ol>


        <div class="content">
            <div class="animated fadeIn">

                <h5 class="heading-title mb-1 text-secondary">Fixed Grid</h5>
                <div class="row">
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                    <div class="col">
                        <section class="card">
                            <div class="card-body text-secondary">.col</div>
                        </section>
                    </div>
                </div>



                <h5 class="heading-title mb-1 mt-4 text-secondary">Desktop Grid</h5>
                <div class="row">
                    <div class="col col-lg-12">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-12</div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-6">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-6</div>
                        </section>
                    </div>
                    <div class="col-lg-6 ">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-6</div>
                        </section>
                    </div>
                </div>


                <div class="row">
                    <div class="col-lg-4">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-4</div>
                        </section>
                    </div>
                    <div class="col-lg-4">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-4</div>
                        </section>
                    </div>
                    <div class="col-lg-4">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-4</div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-3">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-3</div>
                        </section>
                    </div>
                    <div class="col-lg-3">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-3</div>
                        </section>
                    </div>
                    <div class="col-lg-3">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-3</div>
                        </section>
                    </div>
                    <div class="col-lg-3">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-3</div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-2">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-2</div>
                        </section>
                    </div>
                    <div class="col-lg-2">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-2</div>
                        </section>
                    </div>
                    <div class="col-lg-2">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-2</div>
                        </section>
                    </div>
                    <div class="col-lg-2">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-2</div>
                        </section>
                    </div>
                    <div class="col-lg-2">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-2</div>
                        </section>
                    </div>
                    <div class="col-lg-2">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-2</div>
                        </section>
                    </div>
                </div>


                <h4 class="heading-title mt-5 mb-3 text-secondary">Mobile, Tablet, and Desktop</h4>

                <div class="row">
                    <div class="col-2">
                        <section class="card">
                            <div class="card-body text-secondary">col-2</div>
                        </section>
                    </div>
                    <div class="col-2">
                        <section class="card">
                            <div class="card-body text-secondary">col-2</div>
                        </section>
                    </div>
                    <div class="col-lg-8">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-8</div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-3">
                        <section class="card">
                            <div class="card-body text-secondary">col-sm-3</div>
                        </section>
                    </div>
                    <div class="col-sm-3">
                        <section class="card">
                            <div class="card-body text-secondary">col-sm-3</div>
                        </section>
                    </div>
                    <div class="col-lg-6">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-6</div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <section class="card">
                            <div class="card-body text-secondary">col-md-4</div>
                        </section>
                    </div>
                    <div class="col-md-4">
                        <section class="card">
                            <div class="card-body text-secondary">col-md-4</div>
                        </section>
                    </div>
                    <div class="col-lg-4">
                        <section class="card">
                            <div class="card-body text-secondary">col-lg-4</div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <section class="card">
                            <div class="card-body text-secondary">col-sm-6</div>
                        </section>
                    </div>
                    <div class="col-sm-6">
                        <section class="card">
                            <div class="card-body text-secondary">col-sm-6</div>
                        </section>
                    </div>
                </div>


                <h5 class="heading-title mb-1 mt-4 text-secondary">Offset Grid</h5>

                <div class="row">
                    <div class="col-md-6 offset-md-6 col-sm-6 ml-auto">
                        <section class="card">
                            <div class="card-body text-secondary">col-md-6 offset-md-6 col-sm-6 </div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 offset-md-3 mr-auto ml-auto">
                        <section class="card">
                            <div class="card-body text-secondary">.col-md-6 .offset-md-3</div>
                        </section>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <section class="card">
                            <div class="card-body text-secondary"> .col-md-4 </div>
                        </section>
                    </div>
                    <div class="col-md-4 ml-auto">
                        <section class="card">
                            <div class="card-body text-secondary">.col-md-4 .ml-auto</div>
                        </section>
                    </div>
                </div>
            </div>
        </div><!-- .content -->

        <?php include_once 'footer_back.php'; ?>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>

</body>
</html>
